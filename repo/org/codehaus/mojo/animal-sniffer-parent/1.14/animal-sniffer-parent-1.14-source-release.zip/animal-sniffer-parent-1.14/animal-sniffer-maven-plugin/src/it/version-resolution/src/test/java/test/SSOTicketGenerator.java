/**
 * 
 */
package test;


/**
 * @author djeanprost
 */
public class SSOTicketGenerator {

    /**
     * @param args
     */
    public static void main(final String[] args) {

    }
}
